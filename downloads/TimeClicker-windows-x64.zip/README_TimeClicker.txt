TimeClicker 使用说明

GitHub：
- https://github.com/stevengeyue

文件：
- TimeClicker.exe

用法：
1. 双击 TimeClicker.exe 启动。
2. 托盘图标左键：如果桌面小窗已隐藏，则打开小窗；如果小窗已显示，则立即记录当前时间并复制到剪贴板。
3. 托盘图标右键：打开菜单，可显示/隐藏桌面小窗、切换复制格式、切换外观、打开日志、设置开机启动、退出。
4. 桌面小窗显示当前时间、上次记录时间、当前复制格式；点击“复制”只复制当前时间不写日志，点击“记录”会记录并复制。
5. 小窗右上角的 x 只隐藏窗口，不退出程序；再点托盘图标可以打开。

数据位置：
- 记录日志：%LocalAppData%\TimeClicker\records.ndjson
- 设置文件：%LocalAppData%\TimeClicker\settings.json

内置复制格式：
- yyyy-MM-dd HH:mm:ss
- yyyy/MM/dd HH:mm
- HH:mm:ss
- yyyy-MM-dd
- ISO 8601
- 自定义格式

外观：
- 跟随系统
- 浅色
- 深色
- 淡蓝
- 淡粉

验证命令：
- TimeClicker.exe --record-once
  执行一次“记录 + 复制到剪贴板”后退出，适合脚本或快速自检。
